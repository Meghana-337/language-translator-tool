// Get HTML elements

const inputText = document.getElementById("inputText");
const outputText = document.getElementById("outputText");

const sourceLanguage = document.getElementById("sourceLanguage");
const targetLanguage = document.getElementById("targetLanguage");

const translateButton = document.getElementById("translateButton");
const swapButton = document.getElementById("swapButton");

const clearButton = document.getElementById("clearButton");
const copyButton = document.getElementById("copyButton");

const speakInputButton = document.getElementById("speakInputButton");
const speakOutputButton = document.getElementById("speakOutputButton");

const inputCount = document.getElementById("inputCount");
const outputCount = document.getElementById("outputCount");

const statusMessage = document.getElementById("statusMessage");


// Character counter

inputText.addEventListener("input", () => {

    const count = inputText.value.length;

    inputCount.textContent = `${count} characters`;

});


// Translation function

async function translateText() {

    const text = inputText.value.trim();

    const source = sourceLanguage.value;
    const target = targetLanguage.value;


    // Check empty input

    if (text === "") {

        statusMessage.textContent = "Please enter some text to translate.";

        return;
    }


    // Check same language

    if (source === target) {

        outputText.value = text;

        outputCount.textContent = `${text.length} characters`;

        statusMessage.textContent =
            "Source and target languages are the same.";

        return;
    }


    // Show loading

    translateButton.disabled = true;

    translateButton.textContent = "Translating...";

    statusMessage.textContent = "Please wait...";


    try {

        /*
            MyMemory Translation API

            Format:
            source language | target language
        */

        const languagePair = `${source}|${target}`;

        const url =
            `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${languagePair}`;


        // Send request to API

        const response = await fetch(url);


        if (!response.ok) {

            throw new Error("Translation service unavailable.");

        }


        // Convert response to JSON

        const data = await response.json();


        // Get translated text

        if (
            data &&
            data.responseData &&
            data.responseData.translatedText
        ) {

            const translatedText =
                data.responseData.translatedText;


            // Display result

            outputText.value = translatedText;


            // Update counter

            outputCount.textContent =
                `${translatedText.length} characters`;


            statusMessage.textContent =
                "Translation completed successfully.";

        } else {

            throw new Error("Translation could not be completed.");

        }

    }

    catch (error) {

        console.error(error);

        outputText.value = "";

        statusMessage.textContent =
            "Unable to translate. Please try again.";

    }

    finally {

        translateButton.disabled = false;

        translateButton.textContent = "Translate";

    }

}


// Translate button

translateButton.addEventListener(
    "click",
    translateText
);


// Swap languages

swapButton.addEventListener("click", () => {

    const oldSource = sourceLanguage.value;

    sourceLanguage.value = targetLanguage.value;

    targetLanguage.value = oldSource;


    // Also swap text

    const oldInput = inputText.value;

    inputText.value = outputText.value;

    outputText.value = oldInput;


    // Update counters

    inputCount.textContent =
        `${inputText.value.length} characters`;

    outputCount.textContent =
        `${outputText.value.length} characters`;

    statusMessage.textContent =
        "Languages swapped.";

});


// Clear button

clearButton.addEventListener("click", () => {

    inputText.value = "";

    outputText.value = "";

    inputCount.textContent = "0 characters";

    outputCount.textContent = "0 characters";

    statusMessage.textContent = "";

});


// Copy translated text

copyButton.addEventListener("click", async () => {

    const text = outputText.value.trim();

    if (text === "") {

        statusMessage.textContent =
            "There is no translated text to copy.";

        return;
    }


    try {

        await navigator.clipboard.writeText(text);

        statusMessage.textContent =
            "Translated text copied to clipboard.";

    }

    catch (error) {

        statusMessage.textContent =
            "Unable to copy the text.";

    }

});


// Text-to-speech for input

speakInputButton.addEventListener("click", () => {

    const text = inputText.value.trim();

    if (text === "") {

        statusMessage.textContent =
            "Please enter text first.";

        return;
    }


    const speech = new SpeechSynthesisUtterance(text);

    speech.lang = getSpeechLanguage(sourceLanguage.value);

    window.speechSynthesis.cancel();

    window.speechSynthesis.speak(speech);

});


// Text-to-speech for translated text

speakOutputButton.addEventListener("click", () => {

    const text = outputText.value.trim();

    if (text === "") {

        statusMessage.textContent =
            "Please translate some text first.";

        return;
    }


    const speech = new SpeechSynthesisUtterance(text);

    speech.lang = getSpeechLanguage(targetLanguage.value);

    window.speechSynthesis.cancel();

    window.speechSynthesis.speak(speech);

});


// Convert language code for speech

function getSpeechLanguage(language) {

    const speechLanguages = {

        en: "en-US",

        ta: "ta-IN",

        te: "te-IN",

        hi: "hi-IN",

        fr: "fr-FR",

        de: "de-DE",

        es: "es-ES",

        it: "it-IT",

        ja: "ja-JP",

        ko: "ko-KR",

        zh: "zh-CN",

        ar: "ar-SA"

    };

    return speechLanguages[language] || "en-US";

}